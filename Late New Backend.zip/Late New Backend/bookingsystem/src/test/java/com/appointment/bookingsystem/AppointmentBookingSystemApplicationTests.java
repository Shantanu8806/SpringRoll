package com.appointment.bookingsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppointmentBookingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
