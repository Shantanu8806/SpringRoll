package com.appointment.bookingsystem.services;

import com.appointment.bookingsystem.entity.Appointment;
import com.appointment.bookingsystem.entity.AppointmentStatus;
import com.appointment.bookingsystem.entity.Doctor;
import com.appointment.bookingsystem.repository.AppointmentRepository;
import com.appointment.bookingsystem.repository.DoctorRepository;

import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class DoctorService {

    @Autowired
    private DoctorRepository doctorRepository;

    @Autowired
    private AppointmentRepository appointmentRepository;
    

    @Transactional
    public Doctor createDoctor(Doctor doctor) {
        // 1️⃣ Save doctor to generate ID
        Doctor saved = doctorRepository.save(doctor);

        // 2️⃣ Generate and update doctorCode using a query
        String doctorCode = "D" + String.format("%03d", saved.getId());
        doctorRepository.updateDoctorCode(saved.getId(), doctorCode);

        // 3️⃣ Reflect the change in the returned object
        saved.setDoctorCode(doctorCode);

        return saved;
    }


    // ✅ Get doctor by ID
    public Optional<Doctor> getDoctorProfile(Long doctorId) {
        return doctorRepository.findById(doctorId);
    }

    // ✅ Get all doctors
    public List<Doctor> getAllDoctors() {
        return doctorRepository.findAll();
    }

    // ✅ Update doctor profile
    public Doctor updateDoctor(Long doctorId, Doctor updatedDoctor) {
        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new RuntimeException("Doctor not found with ID: " + doctorId));

        doctor.setName(updatedDoctor.getName());
        doctor.setDob(updatedDoctor.getDob());
        doctor.setExperience(updatedDoctor.getExperience());
        doctor.setQualification(updatedDoctor.getQualification());
        doctor.setAge(updatedDoctor.getAge());
        doctor.setEmail(updatedDoctor.getEmail());
        doctor.setContact(updatedDoctor.getContact());
        doctor.setGender(updatedDoctor.getGender());
        doctor.setConsultationFee(updatedDoctor.getConsultationFee());
        doctor.setDepartment(updatedDoctor.getDepartment());

        // Only update password if provided
        if (updatedDoctor.getPassword() != null && !updatedDoctor.getPassword().isBlank()) {
            doctor.setPassword(updatedDoctor.getPassword());
        }

        return doctorRepository.save(doctor);
    }

    // ✅ Delete doctor
    public void deleteDoctor(Long doctorId) {
        if (!doctorRepository.existsById(doctorId)) {
            throw new RuntimeException("Doctor not found with ID: " + doctorId);
        }
        doctorRepository.deleteById(doctorId);
    }

    // ✅ Update availability
    public Doctor updateAvailability(Long doctorId, boolean available) {
        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new RuntimeException("Doctor not found with ID: " + doctorId));
        doctor.setAvailability(available);
        return doctorRepository.save(doctor);
    }
    public Doctor changePassword(Long doctorId, String newPassword) {
        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new RuntimeException("Doctor not found"));
        doctor.setPassword(newPassword);
        return doctorRepository.save(doctor);
    }


    // ✅ Get all appointments for doctor
    public List<Appointment> getAllAppointments(Long doctorId) {
        return appointmentRepository.findByDoctor_Id(doctorId);
    }

    // ✅ Filter appointments by status
    public List<Appointment> filterByStatus(Long doctorId, AppointmentStatus status) {
        return appointmentRepository.findByDoctor_IdAndStatus(doctorId, status);
    }

    // ✅ Filter appointments by exact date
    public List<Appointment> filterByDate(Long doctorId, LocalDate date) {
        return appointmentRepository.findByDoctorIdAndAppointmentDate(doctorId, date);
    }

    // ✅ Filter appointments by patient name
    public List<Appointment> filterByPatientName(Long doctorId, String patientName) {
        return appointmentRepository.findByDoctorIdAndPatientName(doctorId, patientName);
    }


    public long getTotalDoctors() {
        return doctorRepository.count();
    }
    
 // ✅ Get total doctor count per department
    public List<Map<String, Object>> getDoctorCountByDepartment() {
        List<Object[]> results = doctorRepository.getDoctorCountByDepartment();
        List<Map<String, Object>> response = new ArrayList<>();

        for (Object[] row : results) {
            Map<String, Object> map = new HashMap<>();
            map.put("department", row[0]);
            map.put("doctorCount", row[1]);
            response.add(map);
        }

        return response;
    }
    
    public DoctorService(DoctorRepository doctorRepository) {
        this.doctorRepository = doctorRepository;
    }

    public Map<String, Long> getAvailableDoctorsByDepartment() {
        List<Object[]> result = doctorRepository.countAvailableDoctorsByDepartment();
        Map<String, Long> departmentDoctorCount = new HashMap<>();
        for (Object[] row : result) {
            String departmentName = (String) row[0];
            Long doctorCount = (Long) row[1];
            departmentDoctorCount.put(departmentName, doctorCount);
        }
        return departmentDoctorCount;
    }
}
