package com.appointment.bookingsystem.repository;

import com.appointment.bookingsystem.entity.Prescription;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PrescriptionRepository extends JpaRepository<Prescription, Long> {

    // Find all prescriptions by doctor
    List<Prescription> findByDoctorId(Long doctorId);


    // Find all prescriptions by appointment
    @Query("SELECT p FROM Prescription p WHERE p.appointment.appointmentId = :appointmentId")
    Prescription findByAppointmentId(@Param("appointmentId") Long appointmentId);
}
