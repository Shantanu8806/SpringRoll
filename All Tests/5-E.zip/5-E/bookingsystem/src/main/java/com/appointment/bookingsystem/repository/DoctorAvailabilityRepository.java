package com.appointment.bookingsystem.repository;

import com.appointment.bookingsystem.entity.DoctorAvailability;
import java.time.LocalDate;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DoctorAvailabilityRepository extends JpaRepository<DoctorAvailability, Long> {
	Optional<DoctorAvailability> findByDoctor_IdAndDate(Long doctoreId, LocalDate date);
}
