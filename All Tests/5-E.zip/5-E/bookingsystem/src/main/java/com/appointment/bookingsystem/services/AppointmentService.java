package com.appointment.bookingsystem.services;

import com.appointment.bookingsystem.entity.Appointment;
import com.appointment.bookingsystem.entity.AppointmentStatus;
import com.appointment.bookingsystem.entity.Doctor;
import com.appointment.bookingsystem.entity.DoctorAvailability;
import com.appointment.bookingsystem.entity.Patient;
import com.appointment.bookingsystem.entity.Staff;
import com.appointment.bookingsystem.repository.AppointmentRepository;
import com.appointment.bookingsystem.repository.DoctorAvailabilityRepository;
import com.appointment.bookingsystem.repository.DoctorRepository;
import com.appointment.bookingsystem.repository.PatientRepository;
import com.appointment.bookingsystem.repository.StaffRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
@Transactional
public class AppointmentService {

    @Autowired
    private AppointmentRepository appointmentRepository;
    
    @Autowired
    private DoctorRepository doctorRepository;
    
    @Autowired
    private PatientRepository patientRepository;
    
    @Autowired
    private StaffRepository staffRepository;

    @Autowired
    private NotificationService notificationService;
    
    @Autowired
    private DoctorAvailabilityRepository doctorAvailabilityRepository;

    // --- Get all appointments ---
    public List<Appointment> getAllAppointments() {
        return appointmentRepository.findAllByOrderByAppointmentDateTimeAsc();
    }

    // --- Get appointment by ID ---
    public Optional<Appointment> getAppointmentById(Long id) {
        return appointmentRepository.findById(id);
    }

    // --- Create new appointment ---
//    public Appointment createAppointment(Appointment appointment) {
//        validateAppointment(appointment);
//
//        if (appointmentRepository.existsByDoctorAndAppointmentDateTime(
//                appointment.getDoctor(), appointment.getAppointmentDateTime())) {
//            throw new IllegalArgumentException("Duplicate appointment exists for this doctor at the given time.");
//        }
//
//        if (appointment.getStatus() == null) {
//            appointment.setStatus(AppointmentStatus.SCHEDULED);
//        }
//
//        Appointment savedAppointment = appointmentRepository.save(appointment);
//
//        // Create notifications for Doctor and Staff
//        String message = "New appointment scheduled with Patient " +
//                appointment.getPatient().getName() +
//                " on " + appointment.getAppointmentDateTime().toLocalDate() +
//                " at " + appointment.getAppointmentDateTime().toLocalTime();
//
//        // Doctor notification
//        notificationService.createNotification(
//                new com.appointment.bookingsystem.entity.Notification(
//                        null,
//                        com.appointment.bookingsystem.entity.Notification.TargetUser.DOCTOR,
//                        message,
//                        com.appointment.bookingsystem.entity.Notification.NotificationType.INFO,
//                        null,
//                        false
//                )
//        );
//
//        // Staff notification (if assigned)
//        if (appointment.getStaff() != null) {
//            notificationService.createNotification(
//                    new com.appointment.bookingsystem.entity.Notification(
//                            null,
//                            com.appointment.bookingsystem.entity.Notification.TargetUser.STAFF,
//                            message,
//                            com.appointment.bookingsystem.entity.Notification.NotificationType.INFO,
//                            null,
//                            false
//                    )
//            );
//        }
//
//        return savedAppointment;
//    }
    public Appointment createAppointment(Appointment appointment) {
        // Fetch actual DB references
        Doctor doctor = doctorRepository.findById(appointment.getDoctor().getId())
                .orElseThrow(() -> new IllegalArgumentException("Invalid doctor ID"));
        Patient patient = patientRepository.findById(appointment.getPatient().getPatientId())
                .orElseThrow(() -> new IllegalArgumentException("Invalid patient ID"));
        Staff staff = staffRepository.findById(appointment.getStaff().getStaffId())
                .orElseThrow(() -> new IllegalArgumentException("Invalid staff ID"));

        appointment.setDoctor(doctor);
        appointment.setPatient(patient);
        appointment.setStaff(staff);

        // 🔍 Check doctor's availability on that date
        LocalDate appointmentDate = appointment.getAppointmentDateTime().toLocalDate();
        DoctorAvailability availability = doctorAvailabilityRepository
                .findByDoctor_IdAndDate(doctor.getId(), appointmentDate)
                .orElse(null);

        if (availability != null && !availability.isAvailable()) {
            throw new IllegalArgumentException("Doctor is not available on " + appointmentDate);
        }

        // Validate other business rules
        validateAppointment(appointment);

        // Prevent duplicate appointments
        if (appointmentRepository.existsByDoctorAndAppointmentDateTime(
                appointment.getDoctor(), appointment.getAppointmentDateTime())) {
            throw new IllegalArgumentException("Duplicate appointment exists for this doctor at the given time.");
        }

        // Set status
        if (appointment.getStatus() == null) {
            appointment.setStatus(AppointmentStatus.SCHEDULED);
        }

        // Save appointment
        Appointment savedAppointment = appointmentRepository.save(appointment);

        // Notify doctor and staff
        String message = "New appointment scheduled with Patient " +
                patient.getName() +
                " on " + appointment.getAppointmentDateTime().toLocalDate() +
                " at " + appointment.getAppointmentDateTime().toLocalTime();

        notificationService.createNotification(
                new com.appointment.bookingsystem.entity.Notification(
                        null,
                        com.appointment.bookingsystem.entity.Notification.TargetUser.DOCTOR,
                        message,
                        com.appointment.bookingsystem.entity.Notification.NotificationType.INFO,
                        null,
                        false
                )
        );

        return savedAppointment;
    }


    // --- Update existing appointment ---
    public Appointment updateAppointment(Long id, Appointment appointmentDetails) {
        Appointment existing = appointmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Appointment not found with id: " + id));

        validateAppointment(appointmentDetails);

        boolean doctorChanged = !existing.getDoctor().getId().equals(appointmentDetails.getDoctor().getId());
        boolean timeChanged = !existing.getAppointmentDateTime().equals(appointmentDetails.getAppointmentDateTime());

        if (doctorChanged || timeChanged) {
            boolean slotExists = appointmentRepository.existsByDoctorAndAppointmentDateTime(
                    appointmentDetails.getDoctor(),
                    appointmentDetails.getAppointmentDateTime()
            );
            if (slotExists) {
                throw new IllegalArgumentException(
                        "Time slot is already booked for this doctor at the given time.");
            }
        }

        existing.setDoctor(appointmentDetails.getDoctor());
        existing.setPatient(appointmentDetails.getPatient());
        existing.setAppointmentDateTime(appointmentDetails.getAppointmentDateTime());
        existing.setTimeSlot(appointmentDetails.getTimeSlot());
        existing.setReasonForVisit(appointmentDetails.getReasonForVisit());
        existing.setRemarks(appointmentDetails.getRemarks());

        if (appointmentDetails.getStatus() != null) {
            existing.setStatus(appointmentDetails.getStatus());
        }

        return appointmentRepository.save(existing);
    }

    // --- Update appointment status ---
    public Appointment updateAppointmentStatus(Long id, AppointmentStatus status) {
        Appointment appointment = appointmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Appointment not found with id: " + id));
        appointment.setStatus(status);
        return appointmentRepository.save(appointment);
    }

    // --- Cancel appointment ---
    public Appointment cancelAppointment(Long id) {
        return updateAppointmentStatus(id, AppointmentStatus.CANCELLED);
    }

    // --- Complete appointment ---
    public Appointment completeAppointment(Long id) {
        return updateAppointmentStatus(id, AppointmentStatus.COMPLETED);
    }

    // --- Reschedule appointment ---
    public Appointment rescheduleAppointment(Long id, LocalDateTime newDateTime) {
        Appointment appointment = appointmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Appointment not found with id: " + id));

        if (appointmentRepository.existsByDoctorAndAppointmentDateTime(
                appointment.getDoctor(), newDateTime)) {
            throw new IllegalArgumentException("New time slot is not available for this doctor.");
        }

        appointment.setAppointmentDateTime(newDateTime);
        appointment.setStatus(AppointmentStatus.SCHEDULED);
        return appointmentRepository.save(appointment);
    }

    // --- Staff requests appointment deletion ---
    public void requestDeleteAppointment(Long appointmentId, String requestedBy) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new RuntimeException("Appointment not found with id: " + appointmentId));

        String message = "Staff " + requestedBy + " requested deletion of Appointment ID: "
                + appointmentId + " for Patient " + appointment.getPatient().getName()
                + " on " + appointment.getAppointmentDateTime().toLocalDate()
                + " at " + appointment.getAppointmentDateTime().toLocalTime();

        notificationService.createAdminDeleteRequestNotification(message);
    }

    // --- Actual deletion by admin ---
    public void deleteAppointment(Long id) {
        if (!appointmentRepository.existsById(id)) {
            throw new RuntimeException("Appointment not found with id: " + id);
        }
        appointmentRepository.deleteById(id);
    }

    // --- Search methods ---
    public List<Appointment> searchByPatientName(String patientName) {
        return appointmentRepository.findByPatient_NameContainingIgnoreCaseOrderByAppointmentDateTimeAsc(patientName);
    }

    public List<Appointment> searchByDoctorName(String doctorName) {
        return appointmentRepository.findByDoctor_NameContainingIgnoreCaseOrderByAppointmentDateTimeAsc(doctorName);
    }
    
    public void cancelAppointmentsForDoctorOnDate(Long doctorId, LocalDate date) {
        // Define start and end of the given day
        LocalDateTime startOfDay = date.atStartOfDay();
        LocalDateTime endOfDay = date.atTime(LocalTime.MAX);

        // Fetch all appointments for the doctor on that date
        List<Appointment> appointments = appointmentRepository
                .findByDoctorIdAndAppointmentDateTimeBetween(doctorId, startOfDay, endOfDay);

        // Cancel each appointment
        for (Appointment appt : appointments) {
            appt.setStatus(AppointmentStatus.CANCELLED);
            appt.setRemarks("Cancelled automatically due to doctor unavailability");
            appointmentRepository.save(appt);

            // 🔔 Optional: trigger notification to patient
        }
    }


    // --- Other helpers ---
    public List<Appointment> getAppointmentsByStatus(AppointmentStatus status) {
        return appointmentRepository.findByStatus(status);
    }

    public List<Appointment> getUpcomingAppointments() {
        return appointmentRepository.findByAppointmentDateTimeAfter(LocalDateTime.now());
    }

    public List<Appointment> getAppointmentsByDateRange(LocalDateTime startDate, LocalDateTime endDate) {
        if (startDate.isAfter(endDate)) {
            throw new IllegalArgumentException("Start date cannot be after end date");
        }
        return appointmentRepository.findAppointmentsByDateRange(startDate, endDate);
    }

    public List<Appointment> getTodayAppointmentsByDoctor(Doctor doctor) {
        LocalDate today = LocalDate.now();
        return appointmentRepository.findByDoctorIdAndAppointmentDate(doctor.getId(), today);
    }

    public long getAppointmentCountByStatus(AppointmentStatus status) {
        return appointmentRepository.countByStatus(status);
    }

    public boolean isTimeSlotAvailable(Doctor doctor, LocalDateTime appointmentDateTime) {
        return !appointmentRepository.existsByDoctorAndAppointmentDateTime(doctor, appointmentDateTime);
    }
    
    public Long getTotalAppointments() {
        return appointmentRepository.getTotalAppointments();
    }
    
    public Long getCompletedAppointmentCount() {
        return appointmentRepository.getCompletedAppointmentCount();
    }
    
    public Long getCancelledAppointmentCount() {
        return appointmentRepository.getCancelledAppointmentCount();
    }
    
    public Map<String, Long> getWeeklyTrend() {
        List<Object[]> results = appointmentRepository.getWeeklyAppointmentTrend();
        Map<String, Long> trend = new LinkedHashMap<>();
        for (Object[] row : results) {
            trend.put("Week " + row[0], ((Number) row[1]).longValue());
        }
        return trend;
    }

    public Map<String, Long> getMonthlyTrend() {
        List<Object[]> results = appointmentRepository.getMonthlyAppointmentTrend();
        Map<String, Long> trend = new LinkedHashMap<>();
        for (Object[] row : results) {
            trend.put("Month " + row[0], ((Number) row[1]).longValue());
        }
        return trend;
    }
    
 // ✅ Count of DNH appointments
    public long countDNHAppointments() {
        return appointmentRepository.countByStatus(AppointmentStatus.DNH);
    }
    
    public Map<String, Long> getDailyTrend() {
        List<Object[]> result = appointmentRepository.getDailyAppointmentTrend();
        Map<String, Long> dailyTrend = new LinkedHashMap<>();
        for (Object[] row : result) {
            dailyTrend.put(row[0].toString(), ((Number) row[1]).longValue());
        }
        return dailyTrend;
    }
    
 // ✅ Department-wise appointment count
    public Map<String, Long> getDepartmentWiseAppointmentCount() {
        List<Object[]> results = appointmentRepository.getDepartmentWiseAppointmentCount();
        Map<String, Long> departmentCounts = new LinkedHashMap<>();

        for (Object[] row : results) {
            String departmentName = (String) row[0];
            Long count = ((Number) row[1]).longValue();
            departmentCounts.put(departmentName, count);
        }

        return departmentCounts;
    }
    
    
 

    // --- Validation ---
    private void validateAppointment(Appointment appointment) {
        if (appointment.getPatient() == null) throw new IllegalArgumentException("Patient is required");
        if (appointment.getDoctor() == null) throw new IllegalArgumentException("Doctor is required");
        if (appointment.getAppointmentDateTime() == null) throw new IllegalArgumentException("Appointment date and time is required");
        if (appointment.getAppointmentDateTime().isBefore(LocalDateTime.now())) throw new IllegalArgumentException("Appointment cannot be scheduled in the past");

        int hour = appointment.getAppointmentDateTime().getHour();
        if (hour < 8 || hour >= 18) throw new IllegalArgumentException("Appointments can only be scheduled between 8 AM and 6 PM");

        int dayOfWeek = appointment.getAppointmentDateTime().getDayOfWeek().getValue();
        if (dayOfWeek > 5) throw new IllegalArgumentException("Appointments can only be scheduled on weekdays");
    }
    
}
