package com.appointment.bookingsystem.repository;

import com.appointment.bookingsystem.entity.Doctor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DoctorRepository extends JpaRepository<Doctor, Long> {

    // Find by email (for login/authentication)
    Optional<Doctor> findByEmail(String email);

    // Search doctors by name
    List<Doctor> findByNameContainingIgnoreCase(String name);

    // Find doctors by department
    List<Doctor> findByDepartmentId(Long departmentId);

    // Get only available doctors
    List<Doctor> findByAvailabilityTrue();
    
 // Counts all doctors in the database
    long count();
    
 // ✅ Get doctor count per department for pie chart
    @Query("SELECT d.department.name, COUNT(d) FROM Doctor d GROUP BY d.department.name")
    List<Object[]> getDoctorCountByDepartment();
    
 // Group by department and count only available doctors
    @Query("SELECT d.department.name, COUNT(d) FROM Doctor d WHERE d.availability = true GROUP BY d.department.name")
    List<Object[]> countAvailableDoctorsByDepartment();
    
    @Modifying
    @Query("UPDATE Doctor d SET d.doctorCode = :doctorCode WHERE d.id = :id")
    void updateDoctorCode(@Param("id") Long id, @Param("doctorCode") String doctorCode);
    
    Optional<Doctor> findByDoctorCode(String doctorCode);
}
