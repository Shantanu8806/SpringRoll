package com.appointment.bookingsystem.entity;

public enum AppointmentStatus {
    SCHEDULED,
    COMPLETED,
    CANCELLED,
    DNH // Did Not Happen / No Show
}
