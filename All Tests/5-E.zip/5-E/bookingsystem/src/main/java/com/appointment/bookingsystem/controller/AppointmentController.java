package com.appointment.bookingsystem.controller;

import com.appointment.bookingsystem.dto.AppointmentResponse;
import com.appointment.bookingsystem.entity.Appointment;
import com.appointment.bookingsystem.entity.AppointmentStatus;
import com.appointment.bookingsystem.services.AppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/appointments")
public class AppointmentController {

    @Autowired
    private AppointmentService appointmentService;

    // --- Utility method to map Appointment → DTO ---
    private AppointmentResponse mapToResponse(Appointment a) {
        AppointmentResponse dto = new AppointmentResponse();
        dto.setAppointmentId(a.getAppointmentId());
        dto.setDoctorId(a.getDoctor().getId());
        dto.setDoctorName(a.getDoctor().getName());
        dto.setPatientId(a.getPatient().getPatientId());
        dto.setPatientName(a.getPatient().getName());
        dto.setAppointmentDateTime(a.getAppointmentDateTime());
        dto.setTimeSlot(a.getTimeSlot());
        dto.setReasonForVisit(a.getReasonForVisit());
        dto.setStatus(a.getStatus());
        dto.setRemarks(a.getRemarks());
        return dto;
    }

    // --- Get all appointments ---
    @GetMapping
    public ResponseEntity<List<AppointmentResponse>> getAllAppointments() {
        List<Appointment> appointments = appointmentService.getAllAppointments();
        List<AppointmentResponse> response = appointments.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
        return ResponseEntity.ok(response);
    }

    // --- Get appointment by ID ---
    @GetMapping("/{id}")
    public ResponseEntity<?> getAppointmentById(@PathVariable Long id) {
        return appointmentService.getAppointmentById(id)
                .map(a -> ResponseEntity.ok(mapToResponse(a)))
                .orElse(ResponseEntity.notFound().build());
    }

    // --- Create appointment ---
    @PostMapping
    public ResponseEntity<?> createAppointment(@Valid @RequestBody Appointment appointment) {
        try {
            Appointment created = appointmentService.createAppointment(appointment);
            return ResponseEntity.status(201).body(mapToResponse(created));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Internal server error");
        }
    }

    // --- Update appointment ---
    @PutMapping("/{id}")
    public ResponseEntity<?> updateAppointment(@PathVariable Long id,
                                               @Valid @RequestBody Appointment appointmentDetails) {
        try {
            Appointment updated = appointmentService.updateAppointment(id, appointmentDetails);
            return ResponseEntity.ok(mapToResponse(updated));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(500).body(e.getMessage());
        }
    }

    // --- Request deletion (staff) ---
    @PostMapping("/{id}/request-delete")
    public ResponseEntity<?> requestDeleteAppointment(@PathVariable Long id,
                                                      @RequestParam String requestedBy) {
        try {
            appointmentService.requestDeleteAppointment(id, requestedBy);
            return ResponseEntity.ok("Delete request sent to admin.");
        } catch (Exception e) {
            return ResponseEntity.status(500).body(e.getMessage());
        }
    }

    // --- Delete appointment (admin) ---
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteAppointment(@PathVariable Long id) {
        try {
            appointmentService.deleteAppointment(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
    
    

    // --- Update appointment status ---
    @PatchMapping("/{id}/status")
    public ResponseEntity<?> updateAppointmentStatus(@PathVariable Long id,
                                                     @RequestParam AppointmentStatus status) {
        try {
            Appointment updated = appointmentService.updateAppointmentStatus(id, status);
            return ResponseEntity.ok(mapToResponse(updated));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
    

    // ✅ Stats & Analytics Endpoints
    @GetMapping("/total")
    public Long getTotalAppointments() {
        return appointmentService.getTotalAppointments();
    }

    @GetMapping("/completed/count")
    public Long getCompletedAppointmentCount() {
        return appointmentService.getCompletedAppointmentCount();
    }

    @GetMapping("/cancelled/count")
    public Long getCancelledAppointmentCount() {
        return appointmentService.getCancelledAppointmentCount();
    }

    @GetMapping("/trend/weekly")
    public Map<String, Long> getWeeklyTrend() {
        return appointmentService.getWeeklyTrend();
    }

    @GetMapping("/trend/monthly")
    public Map<String, Long> getMonthlyTrend() {
        return appointmentService.getMonthlyTrend();
    }

    @GetMapping("/dnh-count")
    public ResponseEntity<Long> getDNHAppointmentCount() {
        long count = appointmentService.countDNHAppointments();
        return ResponseEntity.ok(count);
    }

    @GetMapping("/trend/daily")
    public ResponseEntity<Map<String, Long>> getDailyTrend() {
        return ResponseEntity.ok(appointmentService.getDailyTrend());
    }

    @GetMapping("/count/department")
    public ResponseEntity<Map<String, Long>> getDepartmentWiseAppointmentCount() {
        return ResponseEntity.ok(appointmentService.getDepartmentWiseAppointmentCount());
    }
}