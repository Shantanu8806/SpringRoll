package com.appointment.bookingsystem.controller;

import com.appointment.bookingsystem.services.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody Map<String, String> request) {
        String code = request.get("code");     // doctorCode / staffCode / admin
        String password = request.get("password");
        String role = request.get("role");

        Map<String, Object> response = authService.login(code, password, role);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/logout")
    public ResponseEntity<Map<String, Object>> logout() {
        Map<String, Object> response = authService.logout();
        return ResponseEntity.ok(response);
    }
}