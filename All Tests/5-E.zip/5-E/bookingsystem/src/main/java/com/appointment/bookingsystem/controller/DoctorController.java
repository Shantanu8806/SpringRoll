package com.appointment.bookingsystem.controller;

import com.appointment.bookingsystem.dto.AppointmentResponse;
import com.appointment.bookingsystem.dto.DoctorResponse;
import com.appointment.bookingsystem.entity.Appointment;
import com.appointment.bookingsystem.entity.Doctor;
import com.appointment.bookingsystem.services.AppointmentService;
import com.appointment.bookingsystem.services.DoctorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/doctors")
public class DoctorController {

    @Autowired
    private DoctorService doctorService;

    @Autowired
    private AppointmentService appointmentService;


    // ✅ Create doctor
    @PostMapping("/create")
    public ResponseEntity<DoctorResponse> createDoctor(@RequestBody Doctor doctor) {
        Doctor created = doctorService.createDoctor(doctor);
        return ResponseEntity.status(201).body(mapToDoctorResponse(created));
    }

    // ✅ Get doctor profile
    @GetMapping("/{doctorId}")
    public ResponseEntity<DoctorResponse> getDoctorProfile(@PathVariable Long doctorId) {
        return doctorService.getDoctorProfile(doctorId)
                .map(this::mapToDoctorResponse)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // ✅ Get all doctors
    @GetMapping
    public ResponseEntity<List<DoctorResponse>> getAllDoctors() {
        List<Doctor> doctors = doctorService.getAllDoctors();
        List<DoctorResponse> responses = doctors.stream()
                .map(this::mapToDoctorResponse)
                .collect(Collectors.toList());
        return responses.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(responses);
    }

    // ✅ Update doctor
    @PutMapping("/{doctorId}")
    public ResponseEntity<DoctorResponse> updateDoctor(@PathVariable Long doctorId,
                                                       @RequestBody Doctor updatedDoctor) {
        try {
            Doctor doctor = doctorService.updateDoctor(doctorId, updatedDoctor);
            return ResponseEntity.ok(mapToDoctorResponse(doctor));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    // ✅ Delete doctor
    @DeleteMapping("/{doctorId}")
    public ResponseEntity<Void> deleteDoctor(@PathVariable Long doctorId) {
        try {
            doctorService.deleteDoctor(doctorId);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // ✅ Update availability
    @PutMapping("/{doctorId}/availability")
    public ResponseEntity<DoctorResponse> setAvailability(@PathVariable Long doctorId,
                                                          @RequestParam boolean availability) {
        try {
            Doctor doctor = doctorService.updateAvailability(doctorId, availability);
            return ResponseEntity.ok(mapToDoctorResponse(doctor));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // ✅ Get all appointments for a doctor
    @GetMapping("/{doctorId}/appointments")
    public ResponseEntity<List<AppointmentResponse>> getAllAppointments(@PathVariable Long doctorId) {
        List<Appointment> appointments = doctorService.getAllAppointments(doctorId);
        List<AppointmentResponse> responses = appointments.stream()
                .map(this::mapToAppointmentResponse)
                .collect(Collectors.toList());
        return responses.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(responses);
    }

    // ✅ Doctor cancels appointment
    @PutMapping("/appointments/{appointmentId}/cancel")
    public ResponseEntity<AppointmentResponse> cancelAppointment(@PathVariable Long appointmentId) {
        Appointment cancelledAppointment = appointmentService.cancelAppointment(appointmentId);
        return ResponseEntity.ok(mapToAppointmentResponse(cancelledAppointment));
    }

    // ✅ Filter by patient name
    @GetMapping("/{doctorId}/appointments/patient")
    public ResponseEntity<List<AppointmentResponse>> filterByPatient(@PathVariable Long doctorId,
                                                                     @RequestParam String name) {
        List<Appointment> filtered = doctorService.filterByPatientName(doctorId, name);
        List<AppointmentResponse> responses = filtered.stream()
                .map(this::mapToAppointmentResponse)
                .collect(Collectors.toList());
        return responses.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(responses);
    }

    // ✅ Department and count endpoints (unchanged)
    @GetMapping("/count")
    public ResponseEntity<Long> getTotalDoctors() {
        return ResponseEntity.ok(doctorService.getTotalDoctors());
    }

    @GetMapping("/department-distribution")
    public ResponseEntity<?> getDoctorCountByDepartment() {
        return ResponseEntity.ok(doctorService.getDoctorCountByDepartment());
    }

    @GetMapping("/available-by-department")
    public ResponseEntity<Map<String, Long>> getAvailableDoctorsByDepartment() {
        return ResponseEntity.ok(doctorService.getAvailableDoctorsByDepartment());
    }

    // ✅ Helper mapper methods
    private DoctorResponse mapToDoctorResponse(Doctor d) {
        DoctorResponse dto = new DoctorResponse();
        dto.setId(d.getId());
        dto.setName(d.getName());
        dto.setEmail(d.getEmail());
        dto.setContact(d.getContact());
        dto.setQualification(d.getQualification());
        dto.setExperience(d.getExperience());
        dto.setAvailability(d.isAvailability());
        dto.setDepartmentName(d.getDepartment() != null ? d.getDepartment().getName() : null);
        dto.setDoctorCode(d.getDoctorCode());
        return dto;
        
    }

    private AppointmentResponse mapToAppointmentResponse(Appointment a) {
        AppointmentResponse dto = new AppointmentResponse();
        dto.setAppointmentId(a.getAppointmentId());
        dto.setDoctorId(a.getDoctor().getId());
        dto.setDoctorName(a.getDoctor().getName());
        dto.setPatientId(a.getPatient().getPatientId());
        dto.setPatientName(a.getPatient().getName());
        dto.setAppointmentDateTime(a.getAppointmentDateTime());
        dto.setTimeSlot(a.getTimeSlot());
        dto.setReasonForVisit(a.getReasonForVisit());
        dto.setStatus(a.getStatus());
        dto.setRemarks(a.getRemarks());
        return dto;
    }
}