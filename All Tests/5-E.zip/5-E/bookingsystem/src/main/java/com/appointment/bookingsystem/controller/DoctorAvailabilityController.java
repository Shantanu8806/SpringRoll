package com.appointment.bookingsystem.controller;

import com.appointment.bookingsystem.dto.DoctorAvailabilityRequest;
import com.appointment.bookingsystem.services.DoctorAvailabilityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/doctor-availability") // ✅ Base path
public class DoctorAvailabilityController {

    @Autowired
    private DoctorAvailabilityService doctorAvailabilityService;

    @PostMapping("/set") // ✅ Just relative path
    public ResponseEntity<String> setDoctorAvailability(@RequestBody DoctorAvailabilityRequest request) {
        doctorAvailabilityService.setAvailability(
                request.getDoctorId(),
                request.getDate(),
                request.isAvailable()
        );
        return ResponseEntity.ok("Doctor availability updated successfully.");
    }
}
