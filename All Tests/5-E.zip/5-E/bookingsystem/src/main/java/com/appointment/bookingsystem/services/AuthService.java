package com.appointment.bookingsystem.services;

import com.appointment.bookingsystem.entity.Doctor;
import com.appointment.bookingsystem.entity.Staff;
import com.appointment.bookingsystem.repository.DoctorRepository;
import com.appointment.bookingsystem.repository.StaffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Service
public class AuthService {

    @Autowired
    private DoctorRepository doctorRepository;

    @Autowired
    private StaffRepository staffRepository;

    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    // Hardcoded admin credentials
    private static final String ADMIN_USERNAME = "admin";
    private static final String ADMIN_PASSWORD = "admin@123";

    public Map<String, Object> login(String code, String password, String role) {
        Map<String, Object> response = new HashMap<>();

        switch (role.toUpperCase()) {
            case "ADMIN":
                if (ADMIN_USERNAME.equals(code) && ADMIN_PASSWORD.equals(password)) {
                    response.put("isLoggedIn", true);
                    response.put("role", "ADMIN");
                    response.put("message", "Admin login successful");
                } else {
                    response.put("isLoggedIn", false);
                    response.put("message", "Invalid Admin credentials");
                }
                break;

            case "DOCTOR":
                Optional<Doctor> doctorOpt = doctorRepository.findByDoctorCode(code);
                if (doctorOpt.isPresent()) {
                    Doctor doctor = doctorOpt.get();
                    if (encoder.matches(password, doctor.getPassword())) {
                        response.put("isLoggedIn", true);
                        response.put("role", "DOCTOR");
                        response.put("doctorId", doctor.getId());
                        response.put("doctorName", doctor.getName());
                        response.put("message", "Doctor login successful");
                    } else {
                        response.put("isLoggedIn", false);
                        response.put("message", "Invalid password");
                    }
                } else {
                    response.put("isLoggedIn", false);
                    response.put("message", "Doctor not found");
                }
                break;

            case "STAFF":
                Optional<Staff> staffOpt = staffRepository.findByStaffCode(code);
                if (staffOpt.isPresent()) {
                    Staff staff = staffOpt.get();
                    if (encoder.matches(password, staff.getPassword())) {
                        response.put("isLoggedIn", true);
                        response.put("role", "STAFF");
                        response.put("staffId", staff.getStaffId());
                        response.put("staffName", staff.getName());
                        response.put("message", "Staff login successful");
                    } else {
                        response.put("isLoggedIn", false);
                        response.put("message", "Invalid password");
                    }
                } else {
                    response.put("isLoggedIn", false);
                    response.put("message", "Staff not found");
                }
                break;

            default:
                response.put("isLoggedIn", false);
                response.put("message", "Invalid role");
        }

        return response;
    }

    public Map<String, Object> logout() {
        Map<String, Object> response = new HashMap<>();
        response.put("isLoggedIn", false);
        response.put("message", "Logged out successfully");
        return response;
    }
}