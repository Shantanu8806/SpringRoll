package com.appointment.bookingsystem.services;
import com.appointment.bookingsystem.entity.Staff;
import com.appointment.bookingsystem.repository.StaffRepository;

import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class StaffService {

    @Autowired
    private StaffRepository staffRepository;

    @Transactional
    public Staff createStaff(Staff staff) {
        // 1️⃣ Save doctor to generate ID
        Staff saved = staffRepository.save(staff);

        // 2️⃣ Generate and update doctorCode using a query
        String staffCode = "S" + String.format("%03d", saved.getStaffId());
        staffRepository.updateStaffCodeById(saved.getStaffId(), staffCode);

        // 3️⃣ Reflect the change in the returned object
        saved.setStaffCode(staffCode);

        return saved;
    }
    // ✅ Get All Staff
    public List<Staff> getAllStaff() {
        return staffRepository.findAll();
    }

    // ✅ Get Staff by ID
    public Staff getStaffById(Long id) {
        return staffRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Staff not found with ID: " + id));
    }

    // ✅ Update Staff
    public Staff updateStaff(Long id, Staff updatedStaff) {
        Staff existing = staffRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Staff not found with ID: " + id));

        existing.setName(updatedStaff.getName());
        existing.setDob(updatedStaff.getDob());
        existing.setContact(updatedStaff.getContact());
        existing.setEmail(updatedStaff.getEmail());
        existing.setRole(updatedStaff.getRole());
        existing.setAssignedDepartment(updatedStaff.getAssignedDepartment());
        existing.setAvailable(updatedStaff.isAvailable());
        existing.setPassword(updatedStaff.getPassword());

        return staffRepository.save(existing);
    }

    // ✅ Delete Staff
    public void deleteStaff(Long id) {
        if (!staffRepository.existsById(id)) {
            throw new RuntimeException("Staff not found with ID: " + id);
        }
        staffRepository.deleteById(id);
    }
}