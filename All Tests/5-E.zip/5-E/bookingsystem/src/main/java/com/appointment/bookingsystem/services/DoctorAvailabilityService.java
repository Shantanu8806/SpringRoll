package com.appointment.bookingsystem.services;

import com.appointment.bookingsystem.entity.DoctorAvailability;
import com.appointment.bookingsystem.repository.DoctorAvailabilityRepository;
import com.appointment.bookingsystem.repository.DoctorRepository;
import com.appointment.bookingsystem.entity.Doctor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Service
public class DoctorAvailabilityService {

    @Autowired
    private DoctorAvailabilityRepository doctorAvailabilityRepository;

    @Autowired
    private DoctorRepository doctorRepository;

    @Autowired
    private AppointmentService appointmentService;

    public DoctorAvailability setAvailability(Long doctorId, String date, boolean available) {
        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new RuntimeException("Doctor not found"));
        
     // ✅ Convert string date (e.g. "2025-11-10") to LocalDate
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate newdate = LocalDate.parse(date, formatter);

        // ✅ Check if availability record already exists for that doctor & date
        DoctorAvailability availability = doctorAvailabilityRepository
                .findByDoctor_IdAndDate(doctorId, newdate)
                .orElse(null);

        if (availability == null) {
            // 🆕 No record exists — create a new one
            availability = new DoctorAvailability();
            availability.setDoctor(doctor);
            availability.setDate(newdate);
        }

        // ✅ Update availability
        availability.setAvailable(available);

        // ✅ Save or update the record
        doctorAvailabilityRepository.save(availability);

        // ✅ If doctor is marked unavailable → cancel all appointments for that date
        if (!available) {
            appointmentService.cancelAppointmentsForDoctorOnDate(doctorId, newdate);
        }

        return availability;
    }
}